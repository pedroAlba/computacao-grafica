
public enum Modo {

	DESENHO, SELECAO
}
