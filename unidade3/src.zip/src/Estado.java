
public enum Estado {

	SELECAO,
	
	DESENHO
}
